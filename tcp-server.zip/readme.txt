Autor: Efraim de Carvalho Felix RA - 792176

Instruções:
	Servidor:		
		Linguagem: Python
		Execução: python ./server/server.py
	Cliente:
		Linguagem: NodeJs v18.13.0
		Execução: node ./client/client.js

Obs:
No lado do cliente foi deixado alguns arquivos para testes (t.txt, p.txt e e.jpg), podendo assim envia-los para o servidor e recebe-los de volta
Tamanho maximo de arquivo testado: 400mb